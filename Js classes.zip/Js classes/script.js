function moverendomEL(elm) {
    elm.style.position = "absolute"
    elm.style.top = Math.floor(Math.random()  * 90 + 5) +"%";
    elm.style.left = Math.floor(Math.random()  * 90 + 5) +"%";


}

const moverendom = document.querySelector("#move-rendom");

moverendom.addEventListener("mouseenter" , function(e) {
    moverendomEL(e.target);
})